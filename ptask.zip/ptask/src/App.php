<?php 

    declare(strict_types=1);
    namespace Ptask;

    class App {

        private $crateprovider;
        private $binprovider;

        public function __construct() {
            $this->crateprovider = 'https://lookup.binlist.net/';
            $this->binprovider = 'https://api.exchangeratesapi.io/latest';
        }

        public function getBinResults(string $bin){
            $binResults = file_get_contents($this->crateprovider.$bin);
            if($binResults != 'error!'){
                return json_decode($binResults);
            }
            return false;
        }

        public function getRate(string $currency){
            $result = false;
            if($currency != 'EUR'){
                $rate = file_get_contents($this->binprovider);
                if($rate){
                    $rate = json_decode($rate,true);
                    $result = $rate['rates'][$currency];
                }
            }
            return $result;
        }

        public function isEu($country) {
            $result = false;
            switch($country) {
                case 'AT':
                case 'BE':
                case 'BG':
                case 'CY':
                case 'CZ':
                case 'DE':
                case 'DK':
                case 'EE':
                case 'ES':
                case 'FI':
                case 'FR':
                case 'GR':
                case 'HR':
                case 'HU':
                case 'IE':
                case 'IT':
                case 'LT':
                case 'LU':
                case 'LV':
                case 'MT':
                case 'NL':
                case 'PO':
                case 'PT':
                case 'RO':
                case 'SE':
                case 'SI':
                case 'SK':
                    $result = true;
                    return $result;
                default:
                    return $result;
            }
        }

        //-------------------------------------------------------
    }