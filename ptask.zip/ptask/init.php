<?php

    require __DIR__ . '/vendor/autoload.php';

    /* Init main controller */

    $app = new Ptask\App();

    /* Read text file */

    if(isset($argv[1])){

        $get_file = explode("\n", file_get_contents($argv[1]));

        foreach ($get_file as $line) {

            $line = json_decode($line);
            $binResults = $app->getBinResults($line->bin);

            if($binResults){

                $rate = $app->getRate($line->currency);

                //това трябва да се промени
                if ($line->currency == 'EUR' || $rate == NULL) {
                    $result = $line->amount;
                } else if ($line->currency != 'EUR' || $rate > 0) {
                    $result = $line->amount / $rate;
                }

                echo round($result * ($app->isEu($binResults->country->alpha2) ? 0.01 : 0.02),2);
                echo "\n";

            }

        }

    } else {
        echo "No txt file supplied.\n";
    }

?>