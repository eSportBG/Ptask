<?php 
    declare(strict_types=1);
    use PHPUnit\Framework\TestCase;

    final class AppTest extends TestCase {

        public function testDoesBinResultsReturnValue(): void {

            $app = new Ptask\App();
            $this->assertIsObject($app->getBinResults('45717360'));

        }

        public function testGetRateReturnsValue(): void {

            $app = new Ptask\App();
            $this->assertIsFloat($app->getRate('USD'));

        }
    }
